wget --no-check-certificate -O cpp_dataset/dev.lb https://github.com/kakaobrain/g2pM/raw/master/data/dev.lb
wget --no-check-certificate -O cpp_dataset/dev.sent https://github.com/kakaobrain/g2pM/raw/master/data/dev.sent
wget --no-check-certificate -O cpp_dataset/test.lb https://github.com/kakaobrain/g2pM/raw/master/data/test.lb
wget --no-check-certificate -O cpp_dataset/test.sent https://github.com/kakaobrain/g2pM/raw/master/data/test.sent
wget --no-check-certificate -O cpp_dataset/train.lb https://github.com/kakaobrain/g2pM/raw/master/data/train.lb
wget --no-check-certificate -O cpp_dataset/train.sent https://github.com/kakaobrain/g2pM/raw/master/data/train.sent